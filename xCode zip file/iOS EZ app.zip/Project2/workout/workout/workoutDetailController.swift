//
//  workoutDetailController.swift
//  workout
//
//  Created by Michael Basazinew on 5/8/23.
//

import Foundation
import WebKit

class workoutDetailController: UIViewController{
    
    
    @IBOutlet weak var WVSite: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let siteURL = URL(string: PassedWorkout.muscleDetail)
        //let siteURL = URL(string:"https://www.gmu.edu")
        
        let request = URLRequest(url: siteURL!)
        WVSite.load(request)
    }
    
    var PassedWorkout = workout()
    
    
    
}
