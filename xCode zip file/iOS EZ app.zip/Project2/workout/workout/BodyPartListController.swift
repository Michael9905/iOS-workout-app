//
//  BodyPartListController.swift
//  workout
//
//  Created by Michael Basazinew on 5/5/23.
//

import Foundation
import UIKit

class BodyPartsListController : UITableViewController{
    
    override func viewDidLoad(){
        super.viewDidLoad()
        GetJSONDATA()
        //initializeData()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var destController = segue.destination as! ViewController
        
        let index = tableView.indexPathForSelectedRow
        
        let selectedRowWorkout = workoutObjectArray[index!.row]
        
        destController.SplitViewWorkout = selectedRowWorkout
        
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return workoutObjectArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //remember to add Identifier
        
        var myCell = tableView.dequeueReusableCell(withIdentifier: "myCellID")
        
        var cellIndex = indexPath.row
        
        var HT = workoutObjectArray[cellIndex]
        
        
        myCell!.textLabel!.text = HT.muscleName
        myCell!.detailTextLabel!.text = HT.upperLowerBody //you can take this off
        
        var img:UIImage = convertToImage(urlString:  "https://raw.githubusercontent.com/mbasazin/IT315_project/main/abs.png")
        
        myCell!.imageView?.image = img
        
        
        myCell!.textLabel!.font = UIFont.boldSystemFont(ofSize: 22)
        
        return myCell!
        
    }
    
    func convertToImage(urlString: String) -> UIImage{
        
        let imgURL = URL(string:urlString)!
        
        let imgData = try? Data(contentsOf: imgURL)
        
        print(imgData ?? "Error. Image does not exist at URL \(imgURL)")
        
        let img = UIImage(data :imgData!)
        
        return img!
        
    }
    
    
    var workoutObjectArray = [workout]()
    
    
    //JSON
    
    func GetJSONDATA(){
        let endPointString = "https://raw.githubusercontent.com/mbasazin/IT315_project/main/workout.json"//json URL
        
        let endPointURL = URL(string: endPointString)
        
        //pass it to the Data functions
        
        let dataBytes = try? Data(contentsOf: endPointURL!)
        
        //print(dataBytes)
        
        if(dataBytes != nil){
            let dictionary:NSDictionary = (try!JSONSerialization.jsonObject(with: dataBytes!,options:JSONSerialization.ReadingOptions.mutableContainers)) as! NSDictionary
            
            print("Dictionary --:  \(dictionary) ---- \n") // for debugging
            
            //split the ditionary into two parts
            let workoutDictionary = dictionary["workout"]! as! [[String:AnyObject]]
            
            for index in 0...workoutDictionary.count - 1{
                let singleWorkout = workoutDictionary[index]
                let workout = workout()
                
                workout.muscleName = singleWorkout["muscleName"] as! String
                print("muscleName: - \(workout.muscleName)")
                
                workout.muscleImg = singleWorkout["muscleImg"] as! String
                
                workout.muscleSite = singleWorkout["muscleSite"] as! String
                
                workout.muscleDetail = singleWorkout["muscleDetail"] as! String  // new
                
                workout.upperLowerBody = singleWorkout["upperLowerBody"] as! String  // new
                
                workoutObjectArray.append(workout)
                
            }
        }
        
        
    }
    
    
    
}
