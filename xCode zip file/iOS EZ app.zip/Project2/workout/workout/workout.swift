//
//  workout.swift
//  workout
//
//  Created by Michael Basazinew on 3/20/23.
//

import Foundation
import UIKit
import AVKit

class workout{
    var muscleName = ""
    var muscleImg = ""
    var muscleSite = ""
    var muscleDetail = ""  // new
    var upperLowerBody = ""
}
