//
//  ViewController.swift
//  Workout App
//
//  Created by Michael Basazinew on 3/3/23.

//this App is developed as an educational project. Certain materials are included under the fair use exemption of the U.S. Copyright Law and have been prepared according to the multimedia fair use guidelines and are restricted from further use

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    
    
    
    var SplitViewWorkout: workout  = workout()
    
    
    var mySoundFile:AVAudioPlayer!

   // var workoutArray = ["Shoulders", "Chest", "Arms", "Core", "Legs", "Calves"]
    
    var workoutObjectArray = [workout]() //create an array of workouts muscle objects
    
    
    @IBOutlet weak var muscleImg: UIImageView!
    
    @IBOutlet weak var muscleName: UILabel!
    
    
    @IBAction func btnMuscleDetail(_ sender: Any) {
        let browserApp = UIApplication.shared
        let url = URL(string: globalHT.muscleDetail)
        browserApp.open(url!)
    }
    
    
    var globalHT = workout()
    
    //open YouTube video
    @IBAction func btnSite(_ sender: Any) {
        let browserApp = UIApplication.shared
        let url = URL(string: globalHT.muscleSite)
        browserApp.open(url!)
    }
    
    //swich button to select workout
    @IBOutlet weak var SWselect: UISwitch!
    
    @IBAction func SWvalueChanged(_ sender: Any) {
        if SWselect.isOn {
            UserDefaults.standard.set(muscleName.text, forKey: "favorite")
        }
        else{
            UserDefaults.standard.set("", forKey: "favorite")
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //sound global variable
        let urlObject = URL(fileURLWithPath: Bundle.main.path(forResource: "eye_of_the_tiger", ofType: "wav")!)
        mySoundFile = try? AVAudioPlayer(contentsOf: urlObject)
        mySoundFile.play()
        
        setLabels()
        // Do any additional setup after loading the view.
    }
    
    
    // 'More' button to work
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let destinationController = segue.destination as! workoutDetailController
        destinationController.PassedWorkout = SplitViewWorkout
    }
    
    

    func convertToImage(urlString: String) -> UIImage{
        
        let imgURL = URL(string:urlString)!
        
        let imgData = try? Data(contentsOf: imgURL)
        
        print(imgData ?? "Error. Image does not exist at URL \(imgURL)")
        
        let img = UIImage(data :imgData!)
        
        return img!
        
    }
    
    
    
    
    //shake gesture
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        muscleImg.alpha = 0
    }
    
    //animation
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIView.animate(withDuration: 3.0, animations:{
            self.muscleImg.alpha = 1
        })
    
        
        setLabels()
    }
    
    
    @IBAction func btnNext(_ sender: Any) {
        setLabels()
    }
    
    func setLabels(){
        //muscleName.text = workoutArray.randomElement()
        
        //var randomMuscle = workoutObjectArray.randomElement()
        
        var randomMuscle = SplitViewWorkout
        globalHT = randomMuscle
        muscleName.text = randomMuscle.muscleName
        
        //muscleImg.image = UIImage(named: randomMuscle.muscleImg)
        muscleImg.image = convertToImage(urlString: randomMuscle.muscleImg)
        
        //store selected workout muscle
        let fav = UserDefaults.standard.string(forKey: "favorite")
        SWselect.isOn = (randomMuscle.muscleName == fav)
    }
    
    

}

